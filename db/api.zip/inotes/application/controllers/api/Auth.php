<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Auth extends REST_Controller
{
    protected $methods = [
        'register_post' => ['level' => 10],
        'login_post' => ['level' => 10],
        'requestEmailVerification' => ['level' => 10]
    ];

    function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');

        $this->load->library('email');
    }

    function register_post()
    {
        $data = [
            'userId' => md5(uniqid('', true)),
            'photoUrl' => null,
            'firstName' => htmlspecialchars($this->post('firstName')),
            'lastName' => htmlspecialchars($this->post('lastName')),
            'email' => htmlspecialchars($this->post('email')),
            'password' => password_hash($this->post('password'), PASSWORD_DEFAULT),
            'created' => date('d-m-Y H:i:s'),
            'verified' => 0
        ];

        if ($data != null && $data['firstName'] != null && $data['lastName'] != null && $data['email'] != null && $data['password'] != null) {

            switch ($this->User_model->registerUser($data)) {
                case 2: {

                        $this->response([
                            'status' => true,
                            'message' => 'New user has been created!'
                        ], REST_Controller::HTTP_CREATED);

                        break;
                    }
                case 1: {

                        $this->response([
                            'status' => false,
                            'message' => 'internal server error. please try again!'
                        ], REST_Controller::HTTP_INTERNAL_SERVER_ERROR);

                        break;
                    }

                default: {

                        $this->response([
                            'status' => false,
                            'message' => 'User with same email is already exist!'
                        ], REST_Controller::HTTP_NOT_ACCEPTABLE);

                        break;
                    }
            }
        } else {

            $this->response([
                'status' => false,
                'message' => 'Provide firstName, lastName, email and password!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    function login_post()
    {
        $data = [
            'email' => $this->post('email'),
            'password' => $this->post('password')
        ];

        if ($data != null && $data['email'] != null && $data['password'] != null) {

            switch ($this->User_model->loginUser($data)) {

                case 3: {

                        $this->response([
                            'status' => true,
                            'message' => 'Login Successfully!'
                        ], REST_Controller::HTTP_ACCEPTED);

                        break;
                    }

                case 2: {

                        $this->response([
                            'status' => false,
                            'message' => 'Login success but account is not verified!'
                        ], REST_Controller::HTTP_UNAUTHORIZED);

                        break;
                    }

                case 1: {

                        $this->response([
                            'status' => false,
                            'message' => 'Wrong password!'
                        ], REST_Controller::HTTP_NOT_ACCEPTABLE);

                        break;
                    }

                default: {

                        $this->response([
                            'status' => false,
                            'message' => 'Wrong email!'
                        ], REST_Controller::HTTP_BAD_REQUEST);

                        break;
                    }
            }
        } else {

            $this->response([
                'status' => false,
                'message' => 'Provide email and password!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    function requestEmailVerification_get()
    {
        $email = $this->get('email');

        $user_row = $this->User_model->sendEmailVerification($email);

        if ($user_row != null) {
            $this->sendEmailVerification($user_row);

            $this->response([
                'status' => true,
                'message' => 'Email verification was send!'
            ], REST_Controller::HTTP_OK);
        } else {

            $this->response([
                'status' => false,
                'message' => 'User login not found!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    function verification_get()
    {
        $user_id = $this->get('userId');

        switch ($this->User_model->verification($user_id)) {

            case 2: {

                    echo "<h1>Account Verification Successfully!</h1></br><p>You can login now with your account!</p>";

                    break;
                }

            case 1: {

                    echo "<h1>Account Has Been Verified</h1></br><p>You can login now with your account!</p>";

                    break;
                }

            default: {

                    echo "<h1>Account Verification Failure!</h1></br><p>User not found!</p>";

                    break;
                }
        }
    }

    private function sendEmailVerification($data = null)
    {
        $user_id = $data->userId;
        $first_name = $data->firstName;

        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'ssl://smtp.googlemail.com';
        $config['smtp_port'] = 465;
        $config['smtp_timeout'] = '7';
        $config['smtp_user'] = '';  // PUT Your email here
        $config['smtp_pass'] = '';  // PUT Your password
        $config['charset'] = 'utf-8';
        $config['newline'] = "\r\n";
        $config['mailtype'] = 'html';
        $config['validation'] = FALSE;

        $this->email->initialize($config);
        $this->email->from('fajar.agungpramana01@gmail.com', 'info-inotes');
        $this->email->to($data->email);
        $this->email->subject('Email Verification');
        $this->email->message(
            "<h1>Hello $first_name</h1></br>
            <p>Welcome to INotes!,</p></br>
            <p>Thank you for registering. click this link to verify your email:</p></br></br>
            http://192.168.43.150/inotes/api/auth/verification?key=7b1ce4d3-b837-483f-b90b-8417f2c3d96b&userId=$user_id
            </br></br>
            <p>if you don't know about this, please don't response this email!</p>"
        );

        return $this->email->send();
    }
}
