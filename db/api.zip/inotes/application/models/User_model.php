<?php

class User_model extends CI_Model
{

    public function registerUser($data = null)
    {
        if ($this->db->get_where('users', ['email' => $data['email']])->num_rows() == 0) {

            if ($this->db->get_where('users', ['userId' => $data['userId']])->num_rows() == 0) {
                $this->db->insert('users', $data);

                return 2;   // User register successfully
            } else
                return 1;   // Server error user with same id already exists

        }

        return 0;   // Account with same email already exist
    }

    public function loginUser($data = null)
    {
        $user_query = $this->db->get_where('users', ['email' => $data['email']]);

        if ($user_query->num_rows() == 1) {

            foreach ($user_query->result() as $row) {

                if (password_verify($data['password'], $row->password)) {

                    if ($this->isUserVerified($row->verified))
                        return 3;   // Login Success!                
                    else
                        return 2;   // Login success but account not verified!

                } else
                    return 1;   // Wrong password!
            }
        }

        return 0;   // wrong email!
    }

    public function sendEmailVerification($email = null)
    {
        $user_query = $this->db->get_where('users', ['email' => $email]);

        if ($user_query->num_rows() == 1) {

            foreach ($user_query->result() as $row) {

                return $row;
            }
        }
    }

    public function verification($user_id = null)
    {
        $user_query = $this->db->get_where('users', ['userId' => $user_id]);

        if ($user_query->num_rows() == 1) {

            foreach ($user_query->result() as $row) {

                if ($row->verified == 0) {
                    $this->db->update('users', ['verified' => 1], ['userId' => $row->userId]);

                    return 2;   //  user verified successfully
                } else {
                    return 1;   //  user has been verified
                }
            }
        }

        return 0;   // user not found!
    }

    private function isUserVerified($verified = null)
    {
        if ($verified == 1) return true;

        return false;
    }
}
